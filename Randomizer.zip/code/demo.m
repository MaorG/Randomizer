
% demo script
configName = 'C:\school\misc\Randomizer\conf_json.json';
randomizeMasks(configName);